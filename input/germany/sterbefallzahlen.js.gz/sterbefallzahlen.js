<!doctype html>
<html lang="en">
<head>
  <base href="https://www.destatis.de/"/>
  <meta charset="UTF-8"/>
  <title>Weekly deaths in Germany  -  Statistisches Bundesamt</title>
  <meta name="title" content="Weekly deaths in Germany"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=1"/>
  <meta name="generator" content="Government Site Builder"/>
  
  







<meta property="og:site_name" content="Federal Statistical Office"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="Weekly deaths in Germany"/>
<meta property="og:description" content=""/>
<meta property="og:image" content="https://www.destatis.de/_config/SocialMediaImage_Image.jpg?__blob=poster"/>
<meta property="og:image:type" content="image/jpeg"/>
<meta property="og:image:width" content="1200"/>
<meta property="og:image:height" content="630"/>
<meta property="og:url" content="https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html"/>
<meta property="og:locale" content="en_EN"/>
<meta property="og:updated_time" content="2020-11-13T09:51:04+0100" />
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="Weekly deaths in Germany"/>
<meta name="twitter:description" content=""/>
<meta name="twitter:image" content="https://www.destatis.de/_config/SocialMediaImage_Image.jpg?__blob=poster"/>




  <!--
     Realisiert mit dem Government Site Builder.
     Die Content Management Lösung der Bundesverwaltung.
     www.government-site-builder.de
   -->
  <link rel="canonical" href="https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html?cms_showChartData=1"/>
<link rel="glossary" href="EN/Service/Glossary/glossary_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" type="text/html" title="Glossary" />
<link rel="start" href="EN/Home/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" type="text/html" title="Homepage" />
<link rel="contents" href="EN/Service/Sitemap/sitemap_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" type="text/html" title="Sitemap" />
<link rel="search" href="EN/Service/Search/search_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" type="text/html" title="Search" />
<link rel="shortcut icon" href="/SiteGlobals/Frontend/Images/favicon.ico;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?__blob=normal&amp;v=3" type="image/ico" />
  
  
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/normalize.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=1" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/_libs.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=1" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/small.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=30" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/medium.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=25" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/large.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=29" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/custom.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=19" type="text/css"/>
<!--[if IE 9]><link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/addon_iefix_9.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=1" type="text/css"/><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" href="SiteGlobals/Frontend/Styles/addon_iefix.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=1" type="text/css" /><![endif]-->
<link rel="stylesheet" href="SiteGlobals/Frontend/Styles/addon_print.css;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=9" type="text/css" media="print" />


  
    <!-- Piwik -->
   <script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['disableCookies']);
  _paq.push(['setDocumentTitle', document.domain + "/" + document.title]);
  _paq.push(['enableHeartBeatTimer', 30]);
  _paq.push(['addDownloadExtensions', "mp4|mp4b"]);
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//piwik.itzbund.de/";
    _paq.push(['setTrackerUrl', u+'js/']);
    _paq.push(['setSiteId', 58]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'js/'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//piwik.itzbund.de/pwk/js/?idsite=58&rec=1" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->
</head>
<body class="gsb startseite js-off lang-en" data-nn="23768-23864">
  









<div class="wrapperOuter">
  <div class="wrapperInner">
    <a id="Start"></a>
    <h1 class="aural">DESTATIS - Statistisches Bundesamt</h1>
    <p class="navSkip">
      <em>Go to:</em>
    </p>
    <ul class="navSkip">
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1#content">Content</a></li>
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1#navPrimary">Main Menu</a></li>
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1#search">Search</a></li>
    </ul>
    <div id="wrapperDivisions" class="wrapperDivisions">
      <div id="header" class="header">
        <div class="row">
          <div class="small-12 column">
            <div class="row collapse align-justify">
              <div class="column small-12 show-for-large-only">
                <div class="navServiceMeta">
                  <h2 class="aural">Servicemeu</h2>
                  
<ul><li ><a href="EN/Service/Contact/_Contact.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Con­tact</a></li><li  class="navServiceLanguage"><a title="Zum deutschen Auftritt" class="languageLink lang_de" href="DE/Themen/Querschnitt/Corona/_inhalt.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" xml:lang="de" hreflang="de" lang="de">Deutsch</a>
</li></ul>
                </div>
              </div>
              <div class="column shrink">
                <a href="EN/Home/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" class="logo" id="anfang" title="to homepage">
  <img src="/SiteGlobals/Frontend/Images/logo.svg;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?__blob=normal&amp;v=9" alt="Government Site Builder (Link to homepage)" />
</a>
                  
              </div>
              <div class="header__nav column shrink">
                <ul class="nav">
                      <li>
                        <a class="nav__item nav__toggle-search js-search-opener" href="EN/Service/Search/search_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
                          <svg width="24" height="23" viewBox="0 0 24 23" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414"><path d="M23.7 21.3l-5.9-5.7c1.4-1.7 2.2-3.8 2.2-6C20 4.3 15.5 0 10 0S0 4.3 0 9.6s4.5 9.6 10 9.6c2.4 0 4.6-.8 6.3-2.2l6 5.7c.2.2.4.3.7.3.3 0 .5-.1.7-.3.4-.4.4-1 0-1.4zM10 17.2c-4.4 0-8-3.4-8-7.6C2 5.4 5.6 2 10 2s8 3.4 8 7.6c0 4.2-3.6 7.6-8 7.6z" fill="#333" fill-rule="nonzero"/></svg>
                        </a>
                      </li>
                    <li id="navMobileMenu"><a class="nav__item nav__toggle-nav" href="EN/Service/Sitemap/sitemap_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742"><span>Menu</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="l-content-wrapper l-content-wrapper--no-space-inner l-content-wrapper--bg-color l-content-wrapper--gradient l-content-wrapper--inverted l-content-wrapper--less-space-after l-content-wrapper--position" id="header-search">
          <div class="c-search-banner">
            <div class="row collapse">
              <div class="column large-10 large-offset-1">
                <h2 class="aural">Search</h2>
                
<form name="searchService" action="SiteGlobals/Forms/Suche/EN/Servicesuche_Formular.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" method="get" enctype="application/x-www-form-urlencoded" class="c-search-box__form" >
  
  <input type="hidden" name="nn" value="23768"/>
  <input type="hidden" name="resourceId" value="2376" />
  <input type="hidden" name="input_" value="442762" />
  <input type="hidden" name="pageLocale" value="en" />
  <div class="c-search-banner__wrapper">
  
  
<span class="formLabel aural">
  <label for="f2376d2370">Search item </label></span>
<span class="formField">
  <input id="f2376d2370" name="templateQueryString" value="" title="Search item must not beginn with ? or *" type="text" pattern="^[^*?].*$" placeholder="search item" size="26" maxlength="100"/></span>
  
  <input class="image" type="image" src="/SiteGlobals/Forms/_components/Buttons/Submit_weiss.svg;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?__blob=image" id="f2376d2372" name="submit" alt="Search" title="Search" />
</div>
</form>
                <div class="c-search-banner__close">
                  <button class="c-search-banner__close-button js-search-opener">Schließen</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="navBreadcrumbs" class="c-breadcrumb">
          <div class="row">
            <div class="column">
              <h2 class="aural">You are here:</h2>
              
<ol class="c-breadcrumb__list">
  <li class="c-breadcrumb__item"><a href="EN/Home/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" title="Homepage">Homepage</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Themes</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Society and environment</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/Population/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Population</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/Population/Deaths-Life-Expectancy/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Deaths, life expectancy</a></li>
  <li class="c-breadcrumb__item"><strong>Weekly deaths in Germany</strong></li>
</ol>
            </div>
          </div>
        </div>
      <div id="main" class="main row">
  <div id="content" class="content richtext column medium-offset-2 medium-8 large-offset-2 large-7">
    <div class="l-content-wrapper l-content-wrapper--expand-full l-content-wrapper--less-space-after">
      <div class="row">
        <div class="column">
          <div class="c-jumbotron">
            <div class="row">
              <div class="column">
                <div class="c-jumbotron__wrapper">
                  <h1 class="c-jumbotron__heading">
                    Weekly deaths in Germany</h1>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <div class="l-content-wrapper l-content-wrapper--expand-full">
  <div class="row">
    <div class="column" style="position: relative;">
      <div class="c-actions">
        <div class="row">
          <div class="column">
            <ul class="c-actions__list js-actions">
              <li class="c-actions__item">
                <a class="c-actions__action c-actions__action--share" href="mailto:?body=https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1&subject=SeiteTeilen_Subject_en">
                  Share</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="chartData">
    <table class="wide">
  <thead>
    <tr>
    <th>Kalenderwoche</th>

    <th>D2016_Ins</th>

    <th>D2017_Ins</th>

    <th>D2018_Ins</th>

    <th>D2019_Ins</th>

    <th>D2020_Ins</th>

    <th>RKI</th>

    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
       <td>18&nbsp;467</td>
       <td>20&nbsp;918</td>
       <td>19&nbsp;342</td>
       <td>18&nbsp;686</td>
       <td>18&nbsp;899</td>
       <td></td>
      </tr>

    <tr>
      <th>2</th>
       <td>18&nbsp;439</td>
       <td>22&nbsp;070</td>
       <td>18&nbsp;770</td>
       <td>19&nbsp;170</td>
       <td>19&nbsp;426</td>
       <td></td>
      </tr>

    <tr>
      <th>3</th>
       <td>18&nbsp;627</td>
       <td>21&nbsp;236</td>
       <td>19&nbsp;187</td>
       <td>19&nbsp;163</td>
       <td>19&nbsp;173</td>
       <td></td>
      </tr>

    <tr>
      <th>4</th>
       <td>18&nbsp;707</td>
       <td>22&nbsp;083</td>
       <td>19&nbsp;171</td>
       <td>19&nbsp;505</td>
       <td>18&nbsp;932</td>
       <td></td>
      </tr>

    <tr>
      <th>5</th>
       <td>18&nbsp;493</td>
       <td>23&nbsp;640</td>
       <td>19&nbsp;558</td>
       <td>19&nbsp;812</td>
       <td>19&nbsp;784</td>
       <td></td>
      </tr>

    <tr>
      <th>6</th>
       <td>18&nbsp;541</td>
       <td>22&nbsp;744</td>
       <td>20&nbsp;086</td>
       <td>19&nbsp;981</td>
       <td>19&nbsp;020</td>
       <td></td>
      </tr>

    <tr>
      <th>7</th>
       <td>18&nbsp;483</td>
       <td>22&nbsp;683</td>
       <td>21&nbsp;254</td>
       <td>20&nbsp;150</td>
       <td>19&nbsp;631</td>
       <td></td>
      </tr>

    <tr>
      <th>8</th>
       <td>18&nbsp;475</td>
       <td>22&nbsp;266</td>
       <td>22&nbsp;888</td>
       <td>20&nbsp;349</td>
       <td>18&nbsp;933</td>
       <td></td>
      </tr>

    <tr>
      <th>9</th>
       <td>18&nbsp;926</td>
       <td>20&nbsp;930</td>
       <td>25&nbsp;535</td>
       <td>20&nbsp;790</td>
       <td>19&nbsp;475</td>
       <td></td>
      </tr>

    <tr>
      <th>10</th>
       <td>18&nbsp;888</td>
       <td>19&nbsp;102</td>
       <td>26&nbsp;777</td>
       <td>20&nbsp;453</td>
       <td>19&nbsp;624</td>
       <td></td>
      </tr>

    <tr>
      <th>11</th>
       <td>18&nbsp;971</td>
       <td>18&nbsp;665</td>
       <td>24&nbsp;385</td>
       <td>19&nbsp;795</td>
       <td>19&nbsp;869</td>
       <td>17</td>
      </tr>

    <tr>
      <th>12</th>
       <td>18&nbsp;826</td>
       <td>17&nbsp;640</td>
       <td>22&nbsp;777</td>
       <td>19&nbsp;016</td>
       <td>19&nbsp;724</td>
       <td>162</td>
      </tr>

    <tr>
      <th>13</th>
       <td>18&nbsp;617</td>
       <td>17&nbsp;731</td>
       <td>20&nbsp;906</td>
       <td>18&nbsp;562</td>
       <td>19&nbsp;692</td>
       <td>600</td>
      </tr>

    <tr>
      <th>14</th>
       <td>18&nbsp;244</td>
       <td>17&nbsp;028</td>
       <td>20&nbsp;038</td>
       <td>18&nbsp;671</td>
       <td>20&nbsp;632</td>
       <td>1&nbsp;367</td>
      </tr>

    <tr>
      <th>15</th>
       <td>17&nbsp;712</td>
       <td>16&nbsp;901</td>
       <td>19&nbsp;165</td>
       <td>17&nbsp;852</td>
       <td>20&nbsp;493</td>
       <td>1&nbsp;739</td>
      </tr>

    <tr>
      <th>16</th>
       <td>16&nbsp;775</td>
       <td>16&nbsp;637</td>
       <td>17&nbsp;992</td>
       <td>18&nbsp;089</td>
       <td>19&nbsp;264</td>
       <td>1&nbsp;594</td>
      </tr>

    <tr>
      <th>17</th>
       <td>17&nbsp;053</td>
       <td>17&nbsp;634</td>
       <td>17&nbsp;093</td>
       <td>17&nbsp;894</td>
       <td>18&nbsp;536</td>
       <td>1&nbsp;168</td>
      </tr>

    <tr>
      <th>18</th>
       <td>16&nbsp;901</td>
       <td>17&nbsp;129</td>
       <td>16&nbsp;789</td>
       <td>17&nbsp;090</td>
       <td>17&nbsp;886</td>
       <td>783</td>
      </tr>

    <tr>
      <th>19</th>
       <td>17&nbsp;629</td>
       <td>17&nbsp;343</td>
       <td>17&nbsp;226</td>
       <td>17&nbsp;118</td>
       <td>17&nbsp;611</td>
       <td>512</td>
      </tr>

    <tr>
      <th>20</th>
       <td>16&nbsp;601</td>
       <td>17&nbsp;079</td>
       <td>16&nbsp;488</td>
       <td>17&nbsp;315</td>
       <td>16&nbsp;964</td>
       <td>349</td>
      </tr>

    <tr>
      <th>21</th>
       <td>16&nbsp;286</td>
       <td>16&nbsp;451</td>
       <td>16&nbsp;513</td>
       <td>17&nbsp;080</td>
       <td>17&nbsp;140</td>
       <td>270</td>
      </tr>

    <tr>
      <th>22</th>
       <td>16&nbsp;346</td>
       <td>16&nbsp;902</td>
       <td>17&nbsp;039</td>
       <td>16&nbsp;921</td>
       <td>16&nbsp;741</td>
       <td>150</td>
      </tr>

    <tr>
      <th>23</th>
       <td>15&nbsp;799</td>
       <td>15&nbsp;846</td>
       <td>16&nbsp;714</td>
       <td>17&nbsp;491</td>
       <td>17&nbsp;250</td>
       <td>113</td>
      </tr>

    <tr>
      <th>24</th>
       <td>15&nbsp;717</td>
       <td>16&nbsp;087</td>
       <td>15&nbsp;582</td>
       <td>16&nbsp;484</td>
       <td>16&nbsp;571</td>
       <td>72</td>
      </tr>

    <tr>
      <th>25</th>
       <td>16&nbsp;910</td>
       <td>16&nbsp;819</td>
       <td>15&nbsp;843</td>
       <td>16&nbsp;639</td>
       <td>16&nbsp;364</td>
       <td>47</td>
      </tr>

    <tr>
      <th>26</th>
       <td>15&nbsp;699</td>
       <td>16&nbsp;076</td>
       <td>16&nbsp;569</td>
       <td>17&nbsp;918</td>
       <td>17&nbsp;248</td>
       <td>51</td>
      </tr>

    <tr>
      <th>27</th>
       <td>16&nbsp;229</td>
       <td>16&nbsp;424</td>
       <td>16&nbsp;622</td>
       <td>16&nbsp;552</td>
       <td>16&nbsp;406</td>
       <td>45</td>
      </tr>

    <tr>
      <th>28</th>
       <td>16&nbsp;172</td>
       <td>15&nbsp;603</td>
       <td>16&nbsp;070</td>
       <td>16&nbsp;319</td>
       <td>16&nbsp;118</td>
       <td>26</td>
      </tr>

    <tr>
      <th>29</th>
       <td>16&nbsp;985</td>
       <td>16&nbsp;589</td>
       <td>16&nbsp;702</td>
       <td>16&nbsp;856</td>
       <td>16&nbsp;480</td>
       <td>24</td>
      </tr>

    <tr>
      <th>30</th>
       <td>16&nbsp;157</td>
       <td>16&nbsp;058</td>
       <td>18&nbsp;340</td>
       <td>19&nbsp;630</td>
       <td>16&nbsp;865</td>
       <td>31</td>
      </tr>

    <tr>
      <th>31</th>
       <td>15&nbsp;439</td>
       <td>16&nbsp;494</td>
       <td>20&nbsp;371</td>
       <td>17&nbsp;034</td>
       <td>17&nbsp;358</td>
       <td>29</td>
      </tr>

    <tr>
      <th>32</th>
       <td>15&nbsp;487</td>
       <td>15&nbsp;784</td>
       <td>18&nbsp;478</td>
       <td>16&nbsp;540</td>
       <td>17&nbsp;416</td>
       <td>30</td>
      </tr>

    <tr>
      <th>33</th>
       <td>16&nbsp;258</td>
       <td>16&nbsp;148</td>
       <td>16&nbsp;890</td>
       <td>15&nbsp;934</td>
       <td>19&nbsp;596</td>
       <td>28</td>
      </tr>

    <tr>
      <th>34</th>
       <td>17&nbsp;147</td>
       <td>15&nbsp;880</td>
       <td>16&nbsp;612</td>
       <td>16&nbsp;263</td>
       <td>17&nbsp;468</td>
       <td>37</td>
      </tr>

    <tr>
      <th>35</th>
       <td>16&nbsp;101</td>
       <td>16&nbsp;064</td>
       <td>16&nbsp;000</td>
       <td>17&nbsp;637</td>
       <td>16&nbsp;555</td>
       <td>36</td>
      </tr>

    <tr>
      <th>36</th>
       <td>16&nbsp;116</td>
       <td>15&nbsp;706</td>
       <td>16&nbsp;390</td>
       <td>15&nbsp;988</td>
       <td>16&nbsp;621</td>
       <td>18</td>
      </tr>

    <tr>
      <th>37</th>
       <td>16&nbsp;372</td>
       <td>16&nbsp;146</td>
       <td>16&nbsp;292</td>
       <td>16&nbsp;303</td>
       <td>16&nbsp;964</td>
       <td>30</td>
      </tr>

    <tr>
      <th>38</th>
       <td>15&nbsp;606</td>
       <td>16&nbsp;505</td>
       <td>16&nbsp;651</td>
       <td>16&nbsp;500</td>
       <td>17&nbsp;365</td>
       <td>50</td>
      </tr>

    <tr>
      <th>39</th>
       <td>16&nbsp;336</td>
       <td>16&nbsp;747</td>
       <td>15&nbsp;969</td>
       <td>17&nbsp;402</td>
       <td>17&nbsp;214</td>
       <td>65</td>
      </tr>

    <tr>
      <th>40</th>
       <td>16&nbsp;352</td>
       <td>16&nbsp;664</td>
       <td>16&nbsp;622</td>
       <td>16&nbsp;899</td>
       <td>17&nbsp;326</td>
       <td>77</td>
      </tr>

    <tr>
      <th>41</th>
       <td>17&nbsp;427</td>
       <td>17&nbsp;470</td>
       <td>16&nbsp;993</td>
       <td>17&nbsp;666</td>
       <td>17&nbsp;127</td>
       <td>108</td>
      </tr>

    <tr>
      <th>42</th>
       <td>17&nbsp;599</td>
       <td>17&nbsp;139</td>
       <td>16&nbsp;552</td>
       <td>17&nbsp;713</td>
       <td>17&nbsp;189</td>
       <td>212</td>
      </tr>

    <tr>
      <th>43</th>
       <td>17&nbsp;586</td>
       <td>17&nbsp;059</td>
       <td>16&nbsp;608</td>
       <td>17&nbsp;327</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>44</th>
       <td>17&nbsp;580</td>
       <td>16&nbsp;762</td>
       <td>16&nbsp;895</td>
       <td>17&nbsp;488</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>45</th>
       <td>17&nbsp;782</td>
       <td>17&nbsp;371</td>
       <td>17&nbsp;604</td>
       <td>17&nbsp;859</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>46</th>
       <td>18&nbsp;591</td>
       <td>17&nbsp;594</td>
       <td>16&nbsp;842</td>
       <td>18&nbsp;242</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>47</th>
       <td>17&nbsp;911</td>
       <td>17&nbsp;676</td>
       <td>17&nbsp;785</td>
       <td>18&nbsp;535</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>48</th>
       <td>18&nbsp;146</td>
       <td>17&nbsp;877</td>
       <td>18&nbsp;091</td>
       <td>18&nbsp;581</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>49</th>
       <td>18&nbsp;793</td>
       <td>18&nbsp;295</td>
       <td>18&nbsp;342</td>
       <td>19&nbsp;143</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>50</th>
       <td>18&nbsp;885</td>
       <td>18&nbsp;504</td>
       <td>17&nbsp;943</td>
       <td>19&nbsp;101</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>51</th>
       <td>19&nbsp;376</td>
       <td>18&nbsp;500</td>
       <td>18&nbsp;990</td>
       <td>19&nbsp;062</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>52</th>
       <td>19&nbsp;744</td>
       <td>18&nbsp;652</td>
       <td>17&nbsp;954</td>
       <td>18&nbsp;204</td>
       <td></td>
       <td></td>
      </tr>

  </tbody>
</table></div>
  <p class="all">
    <a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768" class="button right">Show chart</a>
  </p>


  </div>
</div>
      <div id="footer" class="footer">
            <div class="footer__related">
  <div class="l-content-wrapper">
    <div class="row">
      <div class="column">
        <h2 class="l-content-wrapper__headline">Related Topics</h2>

                <div class="l-card-grid">
          <div class="row flex-dir-column medium-flex-dir-row">

                  <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Current-Population/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Cur­rent pop­u­la­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Population-Projection/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Pop­u­la­tion pro­jec­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Households-Families/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">House­holds and fam­i­lies</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Migration-Integration/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Mi­gra­tion and in­te­gra­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Births/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Births</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Marriages-Divorces-Life-Partnerships/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Mar­riages, di­vorces and life part­ner­ships</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Migration/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">
  <h3 class="c-card-link__heading">Mi­gra­tion</h3>
</a>

</div>
            </div>
                    </div>
        </div>
                <p>
                    <a href="EN/Themes/Society-Environment/Population/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" class="c-more c-more--prev">Back to: Pop­u­la­tion</a></p>
                </div>
    </div>
  </div>
</div>
                      <div class="footer__wrapper">
          <div class="c-actions c-actions--inverted">
            <div class="row">
              <div class="column">
                <ul class="c-actions__list js-actions">
                  <li class="c-actions__item">
                    <a class="c-actions__action c-actions__action--share" href="mailto:?body=https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1&subject=SeiteTeilen_Subject_en">
                      Share
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>



<div class="row">
  <div class="column">
    <div class="row">
      <div class="column small-12 medium-6">
        
<div class="footer__sitemap">
  <h2 class="aural">Subnavigation of all website sections</h2>
  <h3 class="heading">Our topics</h3>
    <ul class="row">
     <li class="column small-12 large-6">
       <a href="EN/Themes/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Themes</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Methods/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Meth­ods</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Press/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Press</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/About-Us/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">About us</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Service/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Ser­vice</a>
     </li>
    </ul>
</div>
      </div>
      <div class="column small-12 medium-6">
        <div class="row flex-dir-column large-flex-dir-row align-justify">
          <div class="column medium-flex-child-shrink large-6 large-flex-child-grow">
            <div class="footer__contact">
              <h3>Contact</h3>
              <p>Statistisches Bundesamt<br/>
Gustav-Stresemann-Ring 11<br/>
65189 Wiesbaden</p>

                <p><a href="EN/Service/Contact/_Contact.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" class="c-more">Contact Form</a></p>
            </div>
          </div>
          <div class="column medium-flex-child-shrink large-6 large-flex-child-grow">
            <div class="footer__social">
              <h3>Follow us!</h3>
              <ul class="row">
                  <li class="column shrink">
                    <a class="" href="https://twitter.com/destatis_news" title="External link Destatis on Twitter (Opens new window)"
     target="_blank"
     rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414"><g fill="#fff" fill-rule="nonzero"><path d="M22.55 45C10.05 45-.05 34.9-.05 22.5S10.05 0 22.55 0c12.5 0 22.5 10.1 22.5 22.5-.1 12.4-10.1 22.5-22.5 22.5zm0-43c-11.4 0-20.6 9.2-20.6 20.5S11.15 43 22.55 43c11.4 0 20.5-9.2 20.5-20.5S33.85 2 22.55 2z"/><path d="M18.65 32.6c8.7 0 13.7-7.4 13.4-14 .9-.7 1.7-1.5 2.4-2.4-.8.4-1.8.6-2.7.7 1-.6 1.7-1.5 2.1-2.6-.9.5-1.9.9-3 1.1-.9-.9-2.1-1.5-3.4-1.5-3 0-5.3 2.8-4.6 5.8-3.9-.2-7.4-2.1-9.7-4.9-1.2 2.1-.6 4.9 1.5 6.3-.8 0-1.5-.2-2.1-.6-.1 2.2 1.5 4.2 3.8 4.7-.7.2-1.4.2-2.1.1.6 1.9 2.3 3.2 4.4 3.3-2 1.6-4.5 2.2-7 2 1.9 1.2 4.4 2 7 2z"/></g></svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://www.youtube.com/user/destatis" title="External link Destatis Youtube Channel (Opens new window)"
     target="_blank"
     rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;"><g id="Group-16-Copy"><path d="M22.5,45c-12.4,0 -22.5,-10.1 -22.5,-22.5c0,-12.4 10.1,-22.5 22.5,-22.5c12.4,0 22.5,10.1 22.5,22.5c0,12.4 -10.1,22.5 -22.5,22.5Zm0,-43c-11.3,0 -20.5,9.2 -20.5,20.5c0,11.3 9.2,20.5 20.5,20.5c11.3,0 20.5,-9.2 20.5,-20.5c0,-11.3 -9.2,-20.5 -20.5,-20.5Z" style="fill:#fff;fill-rule:nonzero;"/><path d="M35.8,15.3c-0.3,-1.2 -1.3,-2.2 -2.5,-2.5c-2.2,-0.6 -11.1,-0.6 -11.1,-0.6c0,0 -8.9,0 -11.1,0.6c-1.2,0.3 -2.2,1.3 -2.5,2.5c-0.6,2.2 -0.6,6.8 -0.6,6.8c0,0 0,4.6 0.6,6.8c0.3,1.2 1.3,2.2 2.5,2.5c2.2,0.6 11.1,0.6 11.1,0.6c0,0 8.9,0 11.1,-0.6c1.2,-0.3 2.2,-1.3 2.5,-2.5c0.6,-2.2 0.6,-6.8 0.6,-6.8c0,0 0,-4.6 -0.6,-6.8Zm-16.4,11.6l0,-8.8l7,4.4l-7,4.4Z" style="fill:#fff;fill-rule:nonzero;"/></g></svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://www.xing.com/jobs/statistisches-bundesamt" title="External link Destatis (Statistisches Bundesamt) at Xing (Opens new window)"
     target="_blank"
     rel="noopener noreferrer"><?xml version="1.0" encoding="UTF-8"?>
<svg width="45px" height="45px" viewBox="0 0 45 45" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <title>xing</title>
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="footer_xing" fill="#FFFFFF" fill-rule="nonzero">
            <g id="xing">
                <path d="M22.5,43 C33.8218374,43 43,33.8218374 43,22.5 C43,11.1781626 33.8218374,2 22.5,2 C11.1781626,2 2,11.1781626 2,22.5 C2,33.8218374 11.1781626,43 22.5,43 Z M22.5,45 C10.0735931,45 0,34.9264069 0,22.5 C0,10.0735931 10.0735931,0 22.5,0 C34.9264069,0 45,10.0735931 45,22.5 C45,34.9264069 34.9264069,45 22.5,45 Z M19.0769412,17.5403303 L21,20.9739148 C20.9218472,21.1180057 19.9172784,22.9427505 17.9864988,26.4477707 C17.7755316,26.8159656 17.5214838,27 17.2244787,27 L14.4221912,27 C14.2579595,27 14.1369727,26.932054 14.0586146,26.7959518 C13.9804618,26.6598496 13.9804618,26.515969 14.0586146,26.3634269 L17.0251748,20.9855615 C17.0328956,20.9855615 17.0328956,20.9815671 17.0251748,20.9734523 L15.1374347,17.6242537 C15.0435939,17.448208 15.0397335,17.3000387 15.125607,17.179998 C15.196039,17.0600834 15.3210505,17 15.500806,17 L18.3031345,17 C18.6157045,17 18.8736948,17.18004 19.0769412,17.5403303 Z M30.9306175,13.6288024 L24.2739171,24.9226396 L24.2739171,24.9346676 L28.509947,32.3710282 C28.602457,32.5324746 28.6066519,32.6814695 28.5226202,32.8185634 C28.4383235,32.9394364 28.3041288,33 28.1192855,33 L25.1059329,33 C24.7529377,33 24.4754519,32.818521 24.2739171,32.4557748 L20,24.9346252 C20.1513278,24.6766159 22.3827392,20.8798724 26.6945876,13.5440981 C26.9047332,13.1813096 27.1736083,13 27.5015219,13 L30.5398236,13 C30.7247994,13.0001694 30.8547549,13.060733 30.9306175,13.181479 C31.0231275,13.3104413 31.0231275,13.4595632 30.9306175,13.6288024 Z" id="Combined-Shape"></path>
            </g>
        </g>
    </g>
</svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://t.co/2YpoOZhB1y?amp=1" title="External link Destatis (Statistisches Bundesamt) at LinkedIn (Opens new window)"
     target="_blank"
     rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;"><g id="Group-17-Copy"><path d="M22.45,45c-12.4,0 -22.4,-10.1 -22.4,-22.5c0,-12.4 10,-22.5 22.4,-22.5c12.4,0 22.5,10.1 22.5,22.5c0.1,12.4 -10,22.5 -22.5,22.5Zm0,-43c-11.3,0 -20.4,9.2 -20.4,20.5c0,11.3 9.1,20.5 20.4,20.5c11.3,0 20.5,-9.2 20.5,-20.5c0,-11.3 -9.1,-20.5 -20.5,-20.5Z" style="fill:#fff;fill-rule:nonzero;"/><path id="LinkedIn" d="M32.85,23.3l0,7.7l-4.5,0l0,-7.2c0,-1.8 -0.6,-3 -2.3,-3c-1.2,0 -2,0.8 -2.3,1.6c-0.1,0.3 -0.1,0.7 -0.1,1.1l0,7.5l-4.4,0c0,0 0,-12.2 0,-13.5l4.5,0l0,1.9c0.6,-0.9 1.7,-2.2 4,-2.2c2.9,0 5.1,1.9 5.1,6.1Zm-18.3,-12.3c-1.5,0 -2.5,1 -2.5,2.4c0,1.3 1,2.3 2.5,2.3c1.6,0 2.5,-1 2.5,-2.3c0,-1.4 -1,-2.4 -2.5,-2.4Zm-2.3,20l4.5,0l0,-13.5l-4.5,0l0,13.5Z" style="fill:#fff;fill-rule:nonzero;"/></g></svg></a>
                  </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>            <div class="c-to-top">
              <div class="row">
                <div class="column">
                  <p class="navToTop">
                    <a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?nn=23768&amp;cms_showChartData=1#Start">
              

              
              
              
                
                
              

              
              
              
              
                
              
              
              
              
              
              
              
              
              
              

              

  <img src="/SiteGlobals/Frontend/Images/icons/to-top.svg;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?__blob=normal&amp;v=3"
                
                  
     title=""
                  
                

                
     alt=""
                

                
                
                

                

                
    
                

                
   />

              </a>
                  </p>
                </div>
              </div>
            </div>
        </div>

<div class="footer__meta">
  <div class="row">
    <div class="column">
      <div class="row flex-dir-column large-flex-dir-row align-justify">
        <div class="column shrink">
          <ul class="row collapse flex-dir-column medium-flex-dir-row">
            <li class="column shrink"><a href="EN/Service/Legal-Notice/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Le­gal No­tice</a></li>
            <li class="column shrink"><a href="EN/Service/Privacy-Policy/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742">Pri­va­cy Pol­i­cy</a></li>
          </ul>
        </div>
        <div class="column shrink">
          <p>&copy;&nbsp;
              

              
              
              
                
                
              

              
              
              
              
                
              
              
              
              
              
              
              
              
              
              

              

  <img src="/SiteGlobals/Frontend/Images/icons/logo-partial.png;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?__blob=normal&amp;v=2"
                
                  
     title=""
                  
                

                
     alt=""
                

                
                
                

                

                
    
                

                
   />

              &nbsp;Statistisches Bundesamt (Destatis) | 2020</p>
        </div>
      </div>
    </div>
  </div>
</div>      </div>

<div id="cookiebanner" class="cookiebanner" data-animation="true">
  <div class="cookiebannerbox">
    <div>
      <div class="text">
        <h2 class="aural">HinweisCookies</h2><p>Usage data on this website are processed only to the extent necessary and only for specific purposes. Cookies on this website are used exclusively to serve the technical provision and optimisation of the website. Detailed information can be found in our data privacy statement: <a class="RichTextIntLink NavNode" href="EN/Service/Privacy-Policy/_node.html;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742" title="Privacy Policy">Privacy Policy</a></p>

      </div>
      <p class="all">
        <a class="button right close" href="#">Close</a>
      </p>
    </div>
  </div>
</div>    </div>
  </div>
</div>
<script type="text/javascript" src="SiteGlobals/Frontend/JavaScript/init/EN/global.js;jsessionid=377A54505C1D8EB914A5D57B0E30C94E.internet8742?v=13"></script>
<!-- Seite generiert am: Tue Nov 17 06:02:56 CET 2020 -->
</body>
</html>