
<!doctype html>
<html lang="en">
<head>
  <base href="https://www.destatis.de/"/>
  <meta charset="UTF-8"/>
  <title>Weekly deaths in Germany  -  German Federal Statistical Office</title>
  <meta name="title" content="Weekly deaths in Germany"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=1"/>
  <meta name="generator" content="Government Site Builder"/>
  
  







<meta property="og:site_name" content="Federal Statistical Office"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="Weekly deaths in Germany"/>
<meta property="og:description" content=""/>
<meta property="og:image" content="https://www.destatis.de/_config/SocialMediaImage_Image.jpg?__blob=poster"/>
<meta property="og:image:type" content="image/jpeg"/>
<meta property="og:image:width" content="1200"/>
<meta property="og:image:height" content="630"/>
<meta property="og:url" content="https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html"/>
<meta property="og:locale" content="en_EN"/>
<meta property="og:updated_time" content="2022-01-25T12:00:01+0100" />
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="Weekly deaths in Germany"/>
<meta name="twitter:description" content=""/>
<meta name="twitter:image" content="https://www.destatis.de/_config/SocialMediaImage_Image.jpg?__blob=poster"/>




  <!--
     Realisiert mit dem Government Site Builder.
     Die Content Management Lösung der Bundesverwaltung.
     www.government-site-builder.de
   -->
    <link rel="canonical" href="https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html?cms_showChartData=1"/>
<link rel="glossary" href="EN/Service/Glossary/glossary_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" type="text/html" title="Glossary" />
<link rel="start" href="EN/Home/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" type="text/html" title="Homepage" />
<link rel="contents" href="EN/Service/Sitemap/sitemap_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" type="text/html" title="Sitemap" />
<link rel="search" href="EN/Service/Search/search_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" type="text/html" title="Search" />
<link rel="shortcut icon" href="/SiteGlobals/Frontend/Images/favicon.ico;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?__blob=normal&amp;v=3" type="image/ico" />
  
  
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/normalize.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=3" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/_libs.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=1" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/small.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=60" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/medium.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=45" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/large.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=51" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/custom.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=41" type="text/css"/>
<link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/custom_destatis.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=12" type="text/css"/>
<!--[if IE 9]><link rel="stylesheet"  href="SiteGlobals/Frontend/Styles/addon_iefix_9.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=2" type="text/css"/><![endif]-->
<!--[if lte IE 8]><link rel="stylesheet" href="SiteGlobals/Frontend/Styles/addon_iefix.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=1" type="text/css" /><![endif]-->
<link rel="stylesheet" href="SiteGlobals/Frontend/Styles/addon_print.css;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=11" type="text/css" media="print" />


  
    <!-- Piwik -->
   <script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['disableCookies']);
  _paq.push(['setDocumentTitle', document.domain + "/" + document.title]);
  _paq.push(['enableHeartBeatTimer', 30]);
  _paq.push(['addDownloadExtensions', "mp4|mp4b"]);
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//piwik.itzbund.de/";
    _paq.push(['setTrackerUrl', u+'js/']);
    _paq.push(['setSiteId', 58]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'js/'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//piwik.itzbund.de/pwk/js/?idsite=58&rec=1" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->
</head>
<body data-matomo-site-id="58" class="gsb  s-podcasts js-off lang-en" data-nn="23768-23864" >
  









<div class="wrapperOuter" id="wrapperOuter">
  <div class="wrapperInner">
    <a id="Start"></a>
    <h1 class="aural">DESTATIS - Statistisches Bundesamt</h1>
    <p class="navSkip">
      <em>Go to:</em>
    </p>
    <ul class="navSkip">
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?nn=23768&amp;cms_showChartData=1#content">Content</a></li>
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?nn=23768&amp;cms_showChartData=1#navPrimary">Main Menu</a></li>
      <li><a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?nn=23768&amp;cms_showChartData=1#search">Search</a></li>
    </ul>
    <div id="wrapperDivisions" class="wrapperDivisions">
      <header id="header" class="header">
        <div class="row">
          <div class="small-12 column">
            <div class="row collapse align-justify">
              <div class="column small-12 show-for-large-only">
                <div class="navServiceMeta">
                  <h2 class="aural">Servicemeu</h2>
                  
<ul><li ><a href="EN/Service/Contact/_Contact.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Con­tact</a></li><li  class="navServiceLanguage"><a title="Zum deutschen Auftritt" class="languageLink lang_de" href="DE/Themen/Querschnitt/Corona/_inhalt.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" xml:lang="de" hreflang="de" lang="de">Deutsch</a>
</li></ul>
                </div>
              </div>
              <div class="column shrink">
                <a href="EN/Home/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" class="logo" id="anfang" title="to homepage">
  <img src="/SiteGlobals/Frontend/Images/logo.svg;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?__blob=normal&amp;v=9" alt="Logo: Destatis Statistisches Bundesamt (Link to homepage)" />
</a>
                  
              </div>
              <div class="header__nav column shrink">
                <ul class="nav">
                      <li>
                        <a class="nav__item nav__toggle-search js-search-opener" href="EN/Service/Search/search_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" id="search" aria-label="Open search">
                          <svg width="24" height="23" viewBox="0 0 24 23" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414"><path d="M23.7 21.3l-5.9-5.7c1.4-1.7 2.2-3.8 2.2-6C20 4.3 15.5 0 10 0S0 4.3 0 9.6s4.5 9.6 10 9.6c2.4 0 4.6-.8 6.3-2.2l6 5.7c.2.2.4.3.7.3.3 0 .5-.1.7-.3.4-.4.4-1 0-1.4zM10 17.2c-4.4 0-8-3.4-8-7.6C2 5.4 5.6 2 10 2s8 3.4 8 7.6c0 4.2-3.6 7.6-8 7.6z" fill="#333" fill-rule="nonzero"/></svg>
                        </a>
        <div class="l-content-wrapper l-content-wrapper--no-space-inner l-content-wrapper--bg-color l-content-wrapper--gradient l-content-wrapper--inverted l-content-wrapper--less-space-after l-content-wrapper--position" id="header-search">
          <div class="c-search-banner">
            <div class="row collapse">
              <div class="column large-10 large-offset-1">
                <h2 class="aural">Search</h2>
                
<form name="searchService" action="SiteGlobals/Forms/Suche/EN/Servicesuche_Formular.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" method="get" enctype="application/x-www-form-urlencoded" class="c-search-box__form" >
  
  <input type="hidden" name="nn" value="23768"/>
  <input type="hidden" name="resourceId" value="2376" />
  <input type="hidden" name="input_" value="442762" />
  <input type="hidden" name="pageLocale" value="en" />
  <div class="c-search-banner__wrapper">
  
  
<span class="formLabel aural">
  <label for="f2376d2370">Search item </label></span><div class="formField">
  <input id="f2376d2370" name="templateQueryString" value="" title="Search item must not beginn with ? or *" type="text" pattern="^[^*?].*$" placeholder="search item" size="26" maxlength="100"/>
</div>

  
  <input class="image" type="image" src="/SiteGlobals/Forms/_components/Buttons/Submit_weiss.svg;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?__blob=image" id="f2376d2372" name="submit" alt="Search" title="Search" />
</div>
</form>
                <div class="c-search-banner__close">
                  <button class="c-search-banner__close-button js-search-opener">Schließen</button>
                </div>
              </div>
            </div>
          </div>
        </div>
                      </li>
                    <li id="navMobileMenu"><a class="nav__item nav__toggle-nav" href="EN/Service/Sitemap/sitemap_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" id="navPrimary"><span>Menu</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>
        <div id="navBreadcrumbs" class="c-breadcrumb">
          <div class="row">
            <div class="column">
              <h2 class="aural">You are here:</h2>
              
<ol class="c-breadcrumb__list">
  <li class="c-breadcrumb__item"><a href="EN/Home/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
   title="Homepage"
  
  
  >Homepage</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Themes</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Society and environment</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/Population/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Population</a></li>
  <li class="c-breadcrumb__item"><a href="EN/Themes/Society-Environment/Population/Deaths-Life-Expectancy/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Deaths, life expectancy</a></li>
  <li class="c-breadcrumb__item"><strong>Weekly deaths in Germany</strong></li>
</ol>
            </div>
          </div>
        </div>
      <main id="main" class="main row">
  <div id="content" class="content richtext column medium-offset-2 medium-8 large-offset-2 large-7">
    <div class="l-content-wrapper l-content-wrapper--expand-full l-content-wrapper--less-space-after">
      <div class="row">
        <div class="column">
          <div class="c-jumbotron">
            <div class="row">
              <div class="column">
                <div class="c-jumbotron__wrapper">
                  <h1 class="c-jumbotron__heading">
                    Weekly deaths in Germany</h1>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <div class="l-content-wrapper l-content-wrapper--expand-full">
  <div class="row">
    <div class="column" style="position: relative;">
      <div class="c-actions">
        <div class="row">
          <div class="column">
            <ul class="c-actions__list js-actions">
              <li class="c-actions__item">
                <a class="c-actions__action c-actions__action--share" href="mailto:?body=https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?cms_showChartData=1&subject=SeiteTeilen_Subject_en">
                  Share</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="chartData">
    <table class="wide">
  <thead>
    <tr>
    <th>Kalenderwoche</th>

    <th>D2017_Ins</th>

    <th>D2018_Ins</th>

    <th>D2019_Ins</th>

    <th>D2020_Ins</th>

    <th>RKI_2020</th>

    <th>D2021_Ins</th>

    <th>RKI_2021</th>

    <th>D2022_Ins</th>

    <th>RKI_2022</th>

    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
       <td>20&nbsp;918</td>
       <td>19&nbsp;342</td>
       <td>18&nbsp;686</td>
       <td>18&nbsp;883</td>
       <td></td>
       <td>24&nbsp;844</td>
       <td>5&nbsp;551</td>
       <td>20&nbsp;191</td>
       <td></td>
      </tr>

    <tr>
      <th>2</th>
       <td>22&nbsp;070</td>
       <td>18&nbsp;770</td>
       <td>19&nbsp;170</td>
       <td>19&nbsp;408</td>
       <td></td>
       <td>24&nbsp;501</td>
       <td>5&nbsp;044</td>
       <td>19&nbsp;557</td>
       <td></td>
      </tr>

    <tr>
      <th>3</th>
       <td>21&nbsp;236</td>
       <td>19&nbsp;187</td>
       <td>19&nbsp;163</td>
       <td>18&nbsp;953</td>
       <td></td>
       <td>24&nbsp;077</td>
       <td>4&nbsp;784</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>4</th>
       <td>22&nbsp;083</td>
       <td>19&nbsp;171</td>
       <td>19&nbsp;505</td>
       <td>18&nbsp;827</td>
       <td></td>
       <td>22&nbsp;644</td>
       <td>4&nbsp;090</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>5</th>
       <td>23&nbsp;640</td>
       <td>19&nbsp;558</td>
       <td>19&nbsp;812</td>
       <td>19&nbsp;774</td>
       <td></td>
       <td>21&nbsp;734</td>
       <td>3&nbsp;333</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>6</th>
       <td>22&nbsp;744</td>
       <td>20&nbsp;086</td>
       <td>19&nbsp;981</td>
       <td>19&nbsp;038</td>
       <td></td>
       <td>20&nbsp;931</td>
       <td>2&nbsp;680</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>7</th>
       <td>22&nbsp;683</td>
       <td>21&nbsp;254</td>
       <td>20&nbsp;150</td>
       <td>19&nbsp;648</td>
       <td></td>
       <td>20&nbsp;469</td>
       <td>2&nbsp;028</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>8</th>
       <td>22&nbsp;266</td>
       <td>22&nbsp;888</td>
       <td>20&nbsp;349</td>
       <td>18&nbsp;953</td>
       <td></td>
       <td>18&nbsp;950</td>
       <td>1&nbsp;708</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>9</th>
       <td>20&nbsp;930</td>
       <td>25&nbsp;535</td>
       <td>20&nbsp;790</td>
       <td>19&nbsp;505</td>
       <td></td>
       <td>18&nbsp;436</td>
       <td>1&nbsp;357</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>10</th>
       <td>19&nbsp;102</td>
       <td>26&nbsp;777</td>
       <td>20&nbsp;453</td>
       <td>19&nbsp;667</td>
       <td></td>
       <td>18&nbsp;606</td>
       <td>1&nbsp;229</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>11</th>
       <td>18&nbsp;665</td>
       <td>24&nbsp;385</td>
       <td>19&nbsp;795</td>
       <td>19&nbsp;849</td>
       <td>19</td>
       <td>18&nbsp;334</td>
       <td>1&nbsp;108</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>12</th>
       <td>17&nbsp;640</td>
       <td>22&nbsp;777</td>
       <td>19&nbsp;016</td>
       <td>19&nbsp;722</td>
       <td>162</td>
       <td>18&nbsp;390</td>
       <td>1&nbsp;187</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>13</th>
       <td>17&nbsp;731</td>
       <td>20&nbsp;906</td>
       <td>18&nbsp;562</td>
       <td>19&nbsp;678</td>
       <td>601</td>
       <td>18&nbsp;491</td>
       <td>1&nbsp;374</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>14</th>
       <td>17&nbsp;028</td>
       <td>20&nbsp;038</td>
       <td>18&nbsp;671</td>
       <td>20&nbsp;662</td>
       <td>1&nbsp;370</td>
       <td>18&nbsp;818</td>
       <td>1&nbsp;506</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>15</th>
       <td>16&nbsp;901</td>
       <td>19&nbsp;165</td>
       <td>17&nbsp;852</td>
       <td>20&nbsp;502</td>
       <td>1&nbsp;743</td>
       <td>19&nbsp;061</td>
       <td>1&nbsp;507</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>16</th>
       <td>16&nbsp;637</td>
       <td>17&nbsp;992</td>
       <td>18&nbsp;089</td>
       <td>19&nbsp;261</td>
       <td>1&nbsp;596</td>
       <td>19&nbsp;239</td>
       <td>1&nbsp;586</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>17</th>
       <td>17&nbsp;634</td>
       <td>17&nbsp;093</td>
       <td>17&nbsp;894</td>
       <td>18&nbsp;557</td>
       <td>1&nbsp;176</td>
       <td>19&nbsp;506</td>
       <td>1&nbsp;572</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>18</th>
       <td>17&nbsp;129</td>
       <td>16&nbsp;789</td>
       <td>17&nbsp;090</td>
       <td>17&nbsp;920</td>
       <td>797</td>
       <td>19&nbsp;308</td>
       <td>1&nbsp;417</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>19</th>
       <td>17&nbsp;343</td>
       <td>17&nbsp;226</td>
       <td>17&nbsp;118</td>
       <td>17&nbsp;651</td>
       <td>516</td>
       <td>18&nbsp;588</td>
       <td>1&nbsp;143</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>20</th>
       <td>17&nbsp;079</td>
       <td>16&nbsp;488</td>
       <td>17&nbsp;315</td>
       <td>17&nbsp;001</td>
       <td>353</td>
       <td>17&nbsp;787</td>
       <td>920</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>21</th>
       <td>16&nbsp;451</td>
       <td>16&nbsp;513</td>
       <td>17&nbsp;080</td>
       <td>17&nbsp;163</td>
       <td>274</td>
       <td>17&nbsp;155</td>
       <td>688</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>22</th>
       <td>16&nbsp;902</td>
       <td>17&nbsp;039</td>
       <td>16&nbsp;921</td>
       <td>16&nbsp;776</td>
       <td>151</td>
       <td>18&nbsp;162</td>
       <td>469</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>23</th>
       <td>15&nbsp;846</td>
       <td>16&nbsp;714</td>
       <td>17&nbsp;491</td>
       <td>17&nbsp;262</td>
       <td>115</td>
       <td>17&nbsp;405</td>
       <td>287</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>24</th>
       <td>16&nbsp;087</td>
       <td>15&nbsp;582</td>
       <td>16&nbsp;484</td>
       <td>16&nbsp;601</td>
       <td>74</td>
       <td>19&nbsp;042</td>
       <td>232</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>25</th>
       <td>16&nbsp;819</td>
       <td>15&nbsp;843</td>
       <td>16&nbsp;639</td>
       <td>16&nbsp;401</td>
       <td>52</td>
       <td>17&nbsp;178</td>
       <td>134</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>26</th>
       <td>16&nbsp;076</td>
       <td>16&nbsp;569</td>
       <td>17&nbsp;918</td>
       <td>17&nbsp;293</td>
       <td>56</td>
       <td>16&nbsp;981</td>
       <td>94</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>27</th>
       <td>16&nbsp;424</td>
       <td>16&nbsp;622</td>
       <td>16&nbsp;552</td>
       <td>16&nbsp;457</td>
       <td>45</td>
       <td>16&nbsp;946</td>
       <td>59</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>28</th>
       <td>15&nbsp;603</td>
       <td>16&nbsp;070</td>
       <td>16&nbsp;319</td>
       <td>16&nbsp;142</td>
       <td>29</td>
       <td>17&nbsp;614</td>
       <td>58</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>29</th>
       <td>16&nbsp;589</td>
       <td>16&nbsp;702</td>
       <td>16&nbsp;856</td>
       <td>16&nbsp;537</td>
       <td>25</td>
       <td>17&nbsp;571</td>
       <td>61</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>30</th>
       <td>16&nbsp;058</td>
       <td>18&nbsp;340</td>
       <td>19&nbsp;630</td>
       <td>16&nbsp;887</td>
       <td>32</td>
       <td>17&nbsp;197</td>
       <td>39</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>31</th>
       <td>16&nbsp;494</td>
       <td>20&nbsp;371</td>
       <td>17&nbsp;034</td>
       <td>17&nbsp;433</td>
       <td>30</td>
       <td>16&nbsp;983</td>
       <td>58</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>32</th>
       <td>15&nbsp;784</td>
       <td>18&nbsp;478</td>
       <td>16&nbsp;540</td>
       <td>17&nbsp;470</td>
       <td>30</td>
       <td>17&nbsp;524</td>
       <td>75</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>33</th>
       <td>16&nbsp;148</td>
       <td>16&nbsp;890</td>
       <td>15&nbsp;934</td>
       <td>19&nbsp;720</td>
       <td>31</td>
       <td>17&nbsp;436</td>
       <td>125</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>34</th>
       <td>15&nbsp;880</td>
       <td>16&nbsp;612</td>
       <td>16&nbsp;263</td>
       <td>17&nbsp;559</td>
       <td>41</td>
       <td>17&nbsp;146</td>
       <td>161</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>35</th>
       <td>16&nbsp;064</td>
       <td>16&nbsp;000</td>
       <td>17&nbsp;637</td>
       <td>16&nbsp;656</td>
       <td>39</td>
       <td>17&nbsp;319</td>
       <td>266</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>36</th>
       <td>15&nbsp;706</td>
       <td>16&nbsp;390</td>
       <td>15&nbsp;988</td>
       <td>16&nbsp;789</td>
       <td>19</td>
       <td>18&nbsp;805</td>
       <td>327</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>37</th>
       <td>16&nbsp;146</td>
       <td>16&nbsp;292</td>
       <td>16&nbsp;303</td>
       <td>17&nbsp;155</td>
       <td>33</td>
       <td>17&nbsp;996</td>
       <td>418</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>38</th>
       <td>16&nbsp;505</td>
       <td>16&nbsp;651</td>
       <td>16&nbsp;500</td>
       <td>17&nbsp;555</td>
       <td>54</td>
       <td>18&nbsp;075</td>
       <td>398</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>39</th>
       <td>16&nbsp;747</td>
       <td>15&nbsp;969</td>
       <td>17&nbsp;402</td>
       <td>17&nbsp;446</td>
       <td>67</td>
       <td>18&nbsp;041</td>
       <td>378</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>40</th>
       <td>16&nbsp;664</td>
       <td>16&nbsp;622</td>
       <td>16&nbsp;899</td>
       <td>17&nbsp;614</td>
       <td>82</td>
       <td>18&nbsp;124</td>
       <td>394</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>41</th>
       <td>17&nbsp;470</td>
       <td>16&nbsp;993</td>
       <td>17&nbsp;666</td>
       <td>17&nbsp;501</td>
       <td>123</td>
       <td>18&nbsp;837</td>
       <td>451</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>42</th>
       <td>17&nbsp;139</td>
       <td>16&nbsp;552</td>
       <td>17&nbsp;713</td>
       <td>17&nbsp;754</td>
       <td>241</td>
       <td>19&nbsp;678</td>
       <td>589</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>43</th>
       <td>17&nbsp;059</td>
       <td>16&nbsp;608</td>
       <td>17&nbsp;327</td>
       <td>18&nbsp;588</td>
       <td>414</td>
       <td>20&nbsp;127</td>
       <td>838</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>44</th>
       <td>16&nbsp;762</td>
       <td>16&nbsp;895</td>
       <td>17&nbsp;488</td>
       <td>18&nbsp;584</td>
       <td>798</td>
       <td>20&nbsp;161</td>
       <td>1&nbsp;173</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>45</th>
       <td>17&nbsp;371</td>
       <td>17&nbsp;604</td>
       <td>17&nbsp;859</td>
       <td>19&nbsp;007</td>
       <td>1&nbsp;265</td>
       <td>20&nbsp;870</td>
       <td>1&nbsp;535</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>46</th>
       <td>17&nbsp;594</td>
       <td>16&nbsp;842</td>
       <td>18&nbsp;242</td>
       <td>19&nbsp;727</td>
       <td>1&nbsp;665</td>
       <td>22&nbsp;083</td>
       <td>1&nbsp;930</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>47</th>
       <td>17&nbsp;676</td>
       <td>17&nbsp;785</td>
       <td>18&nbsp;535</td>
       <td>20&nbsp;182</td>
       <td>2&nbsp;141</td>
       <td>23&nbsp;004</td>
       <td>2&nbsp;358</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>48</th>
       <td>17&nbsp;877</td>
       <td>18&nbsp;091</td>
       <td>18&nbsp;581</td>
       <td>21&nbsp;304</td>
       <td>2&nbsp;927</td>
       <td>23&nbsp;891</td>
       <td>2&nbsp;653</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>49</th>
       <td>18&nbsp;295</td>
       <td>18&nbsp;342</td>
       <td>19&nbsp;143</td>
       <td>22&nbsp;604</td>
       <td>3&nbsp;450</td>
       <td>23&nbsp;672</td>
       <td>2&nbsp;455</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>50</th>
       <td>18&nbsp;504</td>
       <td>17&nbsp;943</td>
       <td>19&nbsp;101</td>
       <td>24&nbsp;003</td>
       <td>4&nbsp;354</td>
       <td>22&nbsp;596</td>
       <td>2&nbsp;284</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>51</th>
       <td>18&nbsp;500</td>
       <td>18&nbsp;990</td>
       <td>19&nbsp;062</td>
       <td>24&nbsp;724</td>
       <td>5&nbsp;281</td>
       <td>22&nbsp;179</td>
       <td>1&nbsp;869</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>52</th>
       <td>18&nbsp;652</td>
       <td>17&nbsp;954</td>
       <td>18&nbsp;204</td>
       <td>25&nbsp;554</td>
       <td>5&nbsp;890</td>
       <td>21&nbsp;734</td>
       <td>1&nbsp;356</td>
       <td></td>
       <td></td>
      </tr>

    <tr>
      <th>53</th>
       <td></td>
       <td></td>
       <td></td>
       <td>25&nbsp;497</td>
       <td>5&nbsp;859</td>
       <td></td>
       <td></td>
       <td></td>
       <td></td>
      </tr>

  </tbody>
</table></div>
  <p class="all">
    <a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" class="button right">Show chart</a>
  </p>


  </div>
</main>
      <footer id="footer" class="footer">
            <div class="footer__related">
  <div class="l-content-wrapper">
    <div class="row">
      <div class="column">
        <h2 class="l-content-wrapper__headline">Related Topics</h2>

                <div class="l-card-grid">
          <div class="row">

                  <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Current-Population/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Cur­rent pop­u­la­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Population-Projection/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Pop­u­la­tion pro­jec­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Households-Families/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">House­holds and fam­i­lies</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Migration-Integration/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Mi­gra­tion and in­te­gra­tion</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Births/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Births</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Marriages-Divorces-Life-Partnerships/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Mar­riages, di­vorces and life part­ner­ships</h3>
</a>

</div>
            </div>
                    <div class="column small-12 medium-4 large-3">
              <div class="l-card-grid__wrapper">
                <a class="c-card-link c-card-link--internal c-card-link--inverted c-card-link--blue" href="EN/Themes/Society-Environment/Population/Migration/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722">
  <h3 class="c-card-link__heading">Mi­gra­tion</h3>
</a>

</div>
            </div>
                    </div>
        </div>
                <p>
                    <a href="EN/Themes/Society-Environment/Population/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
   class="c-more c-more--prev">Back to: Pop­u­la­tion</a></p>
                </div>
    </div>
  </div>
</div>
                      <div class="footer__wrapper">
          <div class="c-actions c-actions--inverted">
            <div class="row">
              <div class="column">
                <ul class="c-actions__list js-actions">
                  <li class="c-actions__item">
                    <a class="c-actions__action c-actions__action--share" href="mailto:?body=https://www.destatis.de/EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?nn=23768&amp;cms_showChartData=1&subject=SeiteTeilen_Subject_en">
                      Share
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>



<div class="row">
  <div class="column small-12">
    <div class="row">
      <div class="column small-12 medium-6">
        
<div class="footer__sitemap">
  <h2 class="aural">Subnavigation of all website sections</h2>
  <h3 class="heading">Our topics</h3>
    <ul class="row">
     <li class="column small-12 large-6">
       <a href="EN/Themes/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Themes</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Methods/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Meth­ods</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Press/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Press</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/About-Us/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >About us</a>
     </li>
     <li class="column small-12 large-6">
       <a href="EN/Service/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Ser­vice</a>
     </li>
    </ul>
</div>
      </div>
      <div class="column small-12 medium-6">
        <div class="row align-justify">
          <div class="column small-12 medium-6">
            <div class="footer__contact">
              <h3>Contact</h3>
              <p>Statistisches Bundesamt<br/>
Gustav-Stresemann-Ring 11<br/>
65189 Wiesbaden</p>

                <p><a href="EN/Service/Contact/_Contact.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
   class="c-more">Contact Form</a></p>
            </div>
          </div>
          <div class="column small-12 medium-6">
            <div class="footer__social">
              <h3>Follow us!</h3>
              <ul class="row large-up-3">
                  <li class="column shrink">
                    <a class="" href="https://twitter.com/destatis_news"
        title="External link Destatis on Twitter (Opens new window)"
  aria-label="External link Destatis on Twitter (Opens new window)"

        target="_blank"
        rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414"><g fill="#fff" fill-rule="nonzero"><path d="M22.55 45C10.05 45-.05 34.9-.05 22.5S10.05 0 22.55 0c12.5 0 22.5 10.1 22.5 22.5-.1 12.4-10.1 22.5-22.5 22.5zm0-43c-11.4 0-20.6 9.2-20.6 20.5S11.15 43 22.55 43c11.4 0 20.5-9.2 20.5-20.5S33.85 2 22.55 2z"/><path d="M18.65 32.6c8.7 0 13.7-7.4 13.4-14 .9-.7 1.7-1.5 2.4-2.4-.8.4-1.8.6-2.7.7 1-.6 1.7-1.5 2.1-2.6-.9.5-1.9.9-3 1.1-.9-.9-2.1-1.5-3.4-1.5-3 0-5.3 2.8-4.6 5.8-3.9-.2-7.4-2.1-9.7-4.9-1.2 2.1-.6 4.9 1.5 6.3-.8 0-1.5-.2-2.1-.6-.1 2.2 1.5 4.2 3.8 4.7-.7.2-1.4.2-2.1.1.6 1.9 2.3 3.2 4.4 3.3-2 1.6-4.5 2.2-7 2 1.9 1.2 4.4 2 7 2z"/></g></svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://www.youtube.com/user/destatis"
        title="External link Destatis Youtube Channel (Opens new window)"
  aria-label="External link Destatis Youtube Channel (Opens new window)"

        target="_blank"
        rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;"><g id="Group-16-Copy"><path d="M22.5,45c-12.4,0 -22.5,-10.1 -22.5,-22.5c0,-12.4 10.1,-22.5 22.5,-22.5c12.4,0 22.5,10.1 22.5,22.5c0,12.4 -10.1,22.5 -22.5,22.5Zm0,-43c-11.3,0 -20.5,9.2 -20.5,20.5c0,11.3 9.2,20.5 20.5,20.5c11.3,0 20.5,-9.2 20.5,-20.5c0,-11.3 -9.2,-20.5 -20.5,-20.5Z" style="fill:#fff;fill-rule:nonzero;"/><path d="M35.8,15.3c-0.3,-1.2 -1.3,-2.2 -2.5,-2.5c-2.2,-0.6 -11.1,-0.6 -11.1,-0.6c0,0 -8.9,0 -11.1,0.6c-1.2,0.3 -2.2,1.3 -2.5,2.5c-0.6,2.2 -0.6,6.8 -0.6,6.8c0,0 0,4.6 0.6,6.8c0.3,1.2 1.3,2.2 2.5,2.5c2.2,0.6 11.1,0.6 11.1,0.6c0,0 8.9,0 11.1,-0.6c1.2,-0.3 2.2,-1.3 2.5,-2.5c0.6,-2.2 0.6,-6.8 0.6,-6.8c0,0 0,-4.6 -0.6,-6.8Zm-16.4,11.6l0,-8.8l7,4.4l-7,4.4Z" style="fill:#fff;fill-rule:nonzero;"/></g></svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://www.xing.com/jobs/statistisches-bundesamt"
        title="External link Destatis (Statistisches Bundesamt) at Xing (Opens new window)"
  aria-label="External link Destatis (Statistisches Bundesamt) at Xing (Opens new window)"

        target="_blank"
        rel="noopener noreferrer"><svg width="45" height="45" xmlns="http://www.w3.org/2000/svg"><path d="M22.5 43C33.822 43 43 33.822 43 22.5S33.822 2 22.5 2 2 11.178 2 22.5 11.178 43 22.5 43zm0 2C10.074 45 0 34.926 0 22.5S10.074 0 22.5 0 45 10.074 45 22.5 34.926 45 22.5 45zm-3.423-27.46L21 20.974c-.078.144-1.083 1.969-3.014 5.474-.21.368-.465.552-.762.552h-2.802a.39.39 0 01-.363-.204.428.428 0 010-.433l2.966-5.377c.008 0 .008-.004 0-.013l-1.888-3.349c-.093-.176-.097-.324-.011-.444.07-.12.195-.18.375-.18h2.802c.313 0 .57.18.774.54zm11.853-3.91l-6.657 11.294v.012l4.236 7.436c.092.161.097.31.013.448-.085.12-.219.181-.404.181h-3.013c-.353 0-.63-.181-.832-.544L20 24.935l6.695-11.39c.21-.364.479-.545.807-.545h3.038c.185 0 .315.06.39.181.093.13.093.279 0 .448z" fill="#FFF" fill-rule="evenodd"/></svg></a>
                  </li>
                  <li class="column shrink">
                    <a class="" href="https://t.co/2YpoOZhB1y?amp=1"
        title="External link Destatis (Statistisches Bundesamt) at LinkedIn (Opens new window)"
  aria-label="External link Destatis (Statistisches Bundesamt) at LinkedIn (Opens new window)"

        target="_blank"
        rel="noopener noreferrer"><svg width="45" height="45" viewBox="0 0 45 45" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;"><g id="Group-17-Copy"><path d="M22.45,45c-12.4,0 -22.4,-10.1 -22.4,-22.5c0,-12.4 10,-22.5 22.4,-22.5c12.4,0 22.5,10.1 22.5,22.5c0.1,12.4 -10,22.5 -22.5,22.5Zm0,-43c-11.3,0 -20.4,9.2 -20.4,20.5c0,11.3 9.1,20.5 20.4,20.5c11.3,0 20.5,-9.2 20.5,-20.5c0,-11.3 -9.1,-20.5 -20.5,-20.5Z" style="fill:#fff;fill-rule:nonzero;"/><path id="LinkedIn" d="M32.85,23.3l0,7.7l-4.5,0l0,-7.2c0,-1.8 -0.6,-3 -2.3,-3c-1.2,0 -2,0.8 -2.3,1.6c-0.1,0.3 -0.1,0.7 -0.1,1.1l0,7.5l-4.4,0c0,0 0,-12.2 0,-13.5l4.5,0l0,1.9c0.6,-0.9 1.7,-2.2 4,-2.2c2.9,0 5.1,1.9 5.1,6.1Zm-18.3,-12.3c-1.5,0 -2.5,1 -2.5,2.4c0,1.3 1,2.3 2.5,2.3c1.6,0 2.5,-1 2.5,-2.3c0,-1.4 -1,-2.4 -2.5,-2.4Zm-2.3,20l4.5,0l0,-13.5l-4.5,0l0,13.5Z" style="fill:#fff;fill-rule:nonzero;"/></g></svg></a>
                  </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>            <div class="c-to-top">
              <div class="row">
                <div class="column">
                  <p class="navToTop">
                    <a href="EN/Themes/Cross-Section/Corona/_Graphic/_Interactive/deaths-weekly-years.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?nn=23768&amp;cms_showChartData=1#Start">
              

              
              
              
                
                
              

              
              
              
              
              
              
              
              
              
              
              
              
              

              

  <img src="/SiteGlobals/Frontend/Images/icons/to-top.svg;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?__blob=normal&amp;v=6"
                
                  
     title="to the top"
                  
                

                
     alt="to the top"
                

                
                
                

                

                
    
                

                
   />

              </a>
                  </p>
                </div>
              </div>
            </div>
        </div>

<div class="footer__meta">
  <div class="row">
    <div class="column small-12">
      <div class="row flex-dir-column large-flex-dir-row align-justify">
        <div class="column shrink">
          <ul class="row collapse flex-dir-column medium-flex-dir-row">
            <li class="column shrink"><a href="EN/Service/Legal-Notice/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Le­gal No­tice</a></li>
            <li class="column shrink"><a href="EN/Service/Privacy-Policy/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722"
  
  
  
  >Pri­va­cy Pol­i­cy</a></li>
          </ul>
        </div>
        <div class="column shrink">
          <p>&copy;&nbsp;
              

              
              
              
                
                
              

              
              
              
              
                
              
              
              
              
              
              
              
              
              
              

              

  <img src="/SiteGlobals/Frontend/Images/icons/logo-partial.png;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?__blob=normal&amp;v=2"
                
                  
     title=""
                  
                

                
     alt=""
                

                
                
                

                

                
    
                

                
   />

              &nbsp;Statistisches Bundesamt (Destatis) | 2022</p>
        </div>
      </div>
    </div>
  </div>
</div>      </footer>
<div id="cookiebanner" class="cookiebanner"
     role="dialog" aria-modal="true" aria-labelledby="cookiebannerhead"
       data-animation="true"
>
  <div class="cookiebannerbox">
    <div>
      <div class="text">
              <h2 id="cookiebannerhead"class="aural">HinweisCookies</h2>
              <p>Usage data on this website are processed only to the extent necessary and only for specific purposes. Cookies on this website are used exclusively to serve the technical provision and optimisation of the website. Detailed information can be found in our data privacy statement: <a class="RichTextIntLink NavNode" href="EN/Service/Privacy-Policy/_node.html;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722" title="Privacy Policy">Privacy Policy</a></p>
</div>
      <p class="all">
              <a class="button right close" href="#">Close</a>
      </p>
    </div>
  </div>
</div>

    </div>
  </div>
</div>
<script type="text/javascript" src="SiteGlobals/Frontend/JavaScript/init/EN/global.js;jsessionid=B37BD16BB1C73DFEEDA59278E9366E9D.live722?v=23"></script>
<!-- Seite generiert am: Wed Jan 26 06:23:54 CET 2022 -->
</body>
</html>